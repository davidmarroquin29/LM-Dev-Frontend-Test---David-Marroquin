var express = require('express');
var router = express.Router();

/* getting product page. */
router.get('/', function(req, res, next) {
  res.render('productos', {page:'productos', menuId:'productos'});
});

module.exports = router;


var fs = require("fs");
console.log("\n *LEYENDO JSON* \n");
var content = fs.readFileSync("productos.json");
console.log("JSON OBTENIDO : \n"+ content);
var jsonContent = JSON.parse(content);
// Get Value from JSON
for (var i = 0; i < jsonContent.productos.length; i++) {
 //console.log("item", jsonContent.productos[i]);
 console.log("Nombre:", jsonContent.productos[i].nombre);
 console.log("Precio:", jsonContent.productos[i].precio);
 console.log("Empresa:", jsonContent.productos[i].empresa);
 console.log("Descripcion:", jsonContent.productos[i].descripcion);
 console.log("Moneda:", jsonContent.productos[i].moneda);
 console.log("Next", "Neext");
}
 
console.log("\n *FIN LECTURA* \n");
